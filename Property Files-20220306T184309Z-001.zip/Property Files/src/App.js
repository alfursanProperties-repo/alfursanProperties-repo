import React, { Fragment } from "react";
import {
  BrowserRouter as Router,
  Routes,
  Route
} from "react-router-dom";
import logo from './logo.svg';
import './App.css';
import SideBar from './Components/SideBar';
import UserForm from './Components/UserForm';
import EmployeeForm from './Components/EmployeeForm';
import EndUserForm from './Components/EndUserForm';
import FileAssignment from './Components/FileAssignment';
import Tabs from './Components/Tabs';
import UsersInfo from './Components/UsersInfo';
import InventoryDetails from './Components/InventoryDetails';
import SingleFileDetail from './Components/SingleFileDetail';
import TabsNext from './Components/TabsNext';
import FileAssignmentNext from './Components/FileAssignmentNext';
import DmsAddNewProductForm from './Components/DmsAddNewProductForm';
import DmsSocietyProfile from './Components/DmsSocietyProfile';
import DmsDealerProfile from './Components/DmsDealerProfile';
import DmsEndUserProfile from './Components/DmsEndUserProfile';
import DmsSocialListings from './Components/DmsSocialListings';
import DmsTransactionHistory from './Components/DmsTransactionHistory';
import DmsPaymentHistory from "./Components/DmsPaymentHistory";
function App() {
  return (
    <div className="App">
      <div className='Div1'>
      <Router>

       

        {/* A <Switch> looks through its children <Route>s and
            renders the first one that matches the current URL. */}
        <Routes>
      <Route exact path="/" element={<><SideBar/><InventoryDetails/></>}  >
        
            
            </Route>
          <Route exact path="/inventory" element={<><SideBar/><InventoryDetails/></>}  >
        
            
          </Route>
         
          <Route exact path="/all-societies" element={<><SideBar/><DmsSocialListings/></>}  >
            
        
            
          </Route>

          <Route exact path="/add-new-society" element={<><SideBar/><DmsAddNewProductForm/></>}  >
            
        
            
          </Route>
          <Route exact path="/users-list" element={<><SideBar/><UsersInfo/></>}  >
            
        
            
          </Route>
          <Route exact path="/add-new-user-form" element={<><SideBar/><UserForm/></>}  >
            
        
            
          </Route>
          <Route exact path="/transaction-history" element={<><SideBar/><DmsTransactionHistory/></>}  >
            
        
            
            </Route>
            <Route exact path="/inventory" element={<><SideBar/><InventoryDetails/></>}  >

            
        
            
            </Route>
            <Route exact path="/payment-history" element={<><SideBar/><DmsPaymentHistory/></>}  >
              
            
        
            
            </Route>
          
          
        </Routes>
    
    </Router>
    
     </div>
    </div>
  );
}

export default App;
