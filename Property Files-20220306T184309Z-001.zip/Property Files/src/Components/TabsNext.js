import React, {useState} from 'react'
import Select from 'react-select';



const options = [
    { value: 'Admin', label: 'Admin' },
    { value: 'User', label: 'User' },
    { value: 'Employee', label: 'Employee' }
  ];

function TabsNext() {
    const [inputValue,setInputValue] = useState('')
    const [selectedValue,setSelectedValue] = useState(null)
  
  
    const handleInputChange = value => {
       setInputValue(value)
    }
    const handleChange = value => {
        setSelectedValue(value)
    }
    
    let ValueHoldingObject={}
    const [toggleState, setToggleState] = useState(1);

    const toggleTab = (index) => {
      setToggleState(index);
    };
  
    return (
        <div className="TabsNextMainDiv">
     
      <div className="container">
        <div className="bloc-tabs">
        <h4 style={{width: "60%", paddingTop: "10px"}} >File Assignment </h4>
          <button
            className={toggleState === 1 ? "tabs active-tabs" : "tabs"}
            onClick={() => toggleTab(1)}
          >
            Al-fursan Properties
          </button>
          <button
            className={toggleState === 2 ? "tabs active-tabs" : "tabs"}
            onClick={() => toggleTab(2)}
          >
            Others
          </button>
          
       
        </div>
  
        <div className="content-tabs">
          <div
            className={toggleState === 1 ? "content  active-content" : "content"}
          >
            <div class="d-flex justify-content-between">
                <div style={{paddingTop: "7px"}}><label>Unit Price:</label></div>
                <div style={{width: "75%"}}>
                    <Select style={{width: "100%"}}  />
                </div>
            </div>
            <div style={{marginTop: "20px"}} class="d-flex justify-content-between">
                <div style={{paddingTop: "7px"}}><label>Minimum Deposit:</label></div>
                <div style={{width: "75%"}}>
                    <div style={{columnGap: "40px"}} className='d-flex flex-row'>
                <div style={{width: "90%"}} class="input-group-prepend">
                <input style={{width: "100%"}} type="text" class="form-control" placeholder="Username" aria-label="Username" aria-describedby="basic-addon1"/>
                
               </div>
               <div style={{width: "90%"}} class="input-group-prepend">
                <input style={{width: "100%"}} type="text" class="form-control" placeholder="Username" aria-label="Username" aria-describedby="basic-addon1"/>
                
               </div>
               </div>
              
                
              
  
                </div>
              
            </div>
            <div style={{marginTop: "20px"}} class="d-flex justify-content-between">
                <div style={{paddingTop: "7px"}}><label>Total Price:</label></div>
                <div style={{width: "75%"}}>
                <input style={{width: "100%"}} type="text" class="form-control" placeholder="Username" aria-label="Username" aria-describedby="basic-addon1"/>
                </div>
            </div>
            <div style={{marginTop: "20px"}} class="d-flex justify-content-between">
                <div style={{paddingTop: "7px"}}><label>Total Discount Deposit:</label></div>
                <div style={{width: "75%"}}>
                    <div style={{columnGap: "40px"}} className='d-flex flex-row'>
                <div style={{width: "90%"}} class="input-group-prepend">
                <input style={{width: "100%"}} type="text" class="form-control" placeholder="Username" aria-label="Username" aria-describedby="basic-addon1"/>
                
               </div>
               <div style={{width: "90%"}} class="input-group-prepend">
                <input style={{width: "100%"}} type="text" class="form-control" placeholder="Username" aria-label="Username" aria-describedby="basic-addon1"/>
                
               </div>
               </div>
              
                
              
  
                </div>
              
            </div>
            <div style={{marginTop: "20px"}} class="d-flex justify-content-between">
                <div style={{paddingTop: "7px"}}><label>Total Payable:</label></div>
                <div style={{width: "75%"}}>
                <input style={{width: "100%"}} type="text" class="form-control" placeholder="Username" aria-label="Username" aria-describedby="basic-addon1"/>
                </div>
            </div>
            <div style={{marginTop: "20px"}} class="d-flex justify-content-between">
                <div style={{paddingTop: "7px"}}><label>Notes/Comments:</label></div>
                <div style={{width: "75%"}}>
                <input style={{width: "100%"}} type="text" class="form-control" placeholder="Username" aria-label="Username" aria-describedby="basic-addon1"/>
                </div>
            </div>
            <div style={{marginTop: "20px"}} class="d-flex flex-row-reverse">
            <div class="p-2"><button style= {{width: "100%", backgroundColor: '#efa804'}} type="button" class="btn-sm">
                    Search Filter
                </button></div>
            <div class="p-2"><button style= {{width: "100%", backgroundColor: "#ececec"}} type="button" class="btn-sm">
                    Search Filter
                </button></div>
            
            </div>
       
  
          <div
            className={toggleState === 2 ? "content  active-content" : "content"}
          >
            <h2>Content 2</h2>
            <hr />
            <p>
              Lorem ipsum dolor sit amet consectetur adipisicing elit. Sapiente
              voluptatum qui adipisci.
            </p>
          </div>
  
        
        </div>
        </div>
      </div>
      </div>
  )
}

export default TabsNext
