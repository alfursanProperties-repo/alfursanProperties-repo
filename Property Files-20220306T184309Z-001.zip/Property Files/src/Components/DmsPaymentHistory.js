import React from 'react';
import Select from 'react-select';
import $ from 'jquery'
import 'jquery/dist/jquery.min.js';
//Datatable Modules
import "datatables.net-dt/js/dataTables.dataTables"

export default function DmsPaymentHistory() {
    $(document).ready(function(){
        $("#hell").DataTable({
            pageLength: 9,
            "bLengthChange": false,
            "ordering": false,
              "bDestroy": true,
              "bInfo": false,
              "dom": "ltipr",
            ajax: {
                url: "https://property-expert-backend-prod.herokuapp.com/plot-files",
                dataSrc: ""
            },
            columns: [
                { data: "fileNo" },
                { data: "fileSecurityNo" },
                { data: "fileType" },
                { data: "projectName" }, 
                { data: "status" }, 
                { data: "assignedDate" }, 
                { data: "recievedDate" }
              
               
            ],          
           
            iDisplayStart: 0
        });
        })
  return (
    <div>
      <div className='AppHeader'>
        <div class="d-flex justify-content-between">
             <div style= {{paddingTop: "2%"}} class="mr-auto p-2">
             <h6 style= {{paddingTop: "5%"}}>Home - Transaction History</h6>
             </div>
             <div style= {{textAlign: "right"}} className='p-2'>
             <img className='ImageAppHeader' src="logo192.png" alt="Avatar"/>
             </div>
       
         </div>
         </div>
    <div>
    <div id='FileAssignmentUpperDiv' class="d-flex justify-content-between">
    <div class="p-2"><h4>Transaction History</h4></div>
    <div style={{marginRight: "30px", color: "#fff"}} class="p-2"></div>
    </div>
    
    </div>
      <div id='BorderedDivDms'>
    <div style={{backgroundColor: "#fff"}} id='DmsProductFormMainDiv'>
        <div class="d-flex flex-row">
        <div style={{width: "50%"}} class="p-2">
        <div class="d-flex flex-row">
        <div style={{width: "33.3%"}} class="p-2" ><Select placeholder='Created Date...'/></div>
        <div style={{width: "33.3%"}} class="p-2"><Select placeholder='Due Date...'/></div>
        <div id='Selection' class="p-2"><Select placeholder='Transaction Type'/></div>
        </div>

        </div>
        <div style={{width: "50%"}} class="p-2">
        <div class="d-flex flex-row-reverse">
        <div style={{width: "25%"}} class="p-2">
        <button style= {{width: "100%"}} type="button" class="btn btn-link">
                    Reset All
                </button>
        </div>
        <div style={{width: "20%"}} class="p-2">
        <button style= {{width: "100%",}} type="button" class="btn btn-dark">
                Filter
                </button>
        </div>
       
        </div>
        </div>
        
        </div>
        <div  >
    <table  id='hell' className='table table-striped' >
        <thead>
            <tr>
                  <th>Payment ID</th>  
                  <th>Payment Type</th> 
                  <th>Transaction ID</th> 
                  <th>Payment Due Date</th> 
                  <th>Amount</th> 
                  <th>Status</th> 
                  <th>Receipt</th> 
               
            
                
            </tr>
        </thead>

    </table>
  </div>
      
    </div>
    </div>
    </div>
  )
}
