import React from 'react'
import Select from 'react-select';
import $ from 'jquery'; 
//Bootstrap and jQuery libraries
import 'bootstrap/dist/css/bootstrap.min.css';
import 'jquery/dist/jquery.min.js';
//Datatable Modules

import "datatables.net-dt/js/dataTables.dataTables"
import Tabs from './Tabs';
function FileAssignment() {

        $(document).ready(function(){
           $("#example").DataTable({
               pageLength: 4,
               "bLengthChange": false,
               "ordering": false,
                 "bDestroy": true,
                 "bInfo": false,
                 "scrollY": '441.6px',
                 "dom": "ltipr",
                 "columnDefs": [ {
                   "targets": -1,
                   "data": null,
                   "defaultContent": "<button>Click!</button>"
               } ],
               ajax: {
                   url: "https://property-expert-backend-prod.herokuapp.com/plot-files",
                   dataSrc: ""
               },
               columns: [
                   { data: "fileNo" },
                   { data: "fileSecurityNo" },
                   { data: "projectName" }, 
                   { data: "status" }, 
                   { data: "assignedDate" }, 
                   { data: "unitPrice" },  
                            
               ],          
              
               iDisplayStart: 0
           });
           })
       
  return (
    <div>
      <div>
        <div className='AppHeader'>
         <div class="d-flex justify-content-between">
              <div style= {{paddingTop: "2%"}} class="mr-auto p-2">
              <h6 style= {{paddingTop: "5%"}}>Home - File Assignment</h6>
              </div>
              <div style= {{textAlign: "right"}} className='p-2'>
              <img className='ImageAppHeader'  src="logo192.png" alt="Avatar"/>
              </div>
        
          </div>
      </div>
      </div>
      <div>
        <div className='FileAssignmentUpperDiv' >
         <div class="d-flex justify-content-between">
              <div style= {{paddingTop: "2%"}} class="mr-auto p-2">
              <h4 style= {{paddingTop: "1%"}}>File Assignment</h4>
              </div>
              <div style= {{textAlign: "right"}} className='p-2'>
              <button id='AddNewFileButton' class="btn-sm">Add New File</button>
              </div>
        
          </div>
      </div>
      </div>
   




      <div className='DropdownStyleDiv' >
         <div style={{paddingTop: "1%"}} class="d-flex justify-content-between">
         <div style= {{width: "60%"}} class="d-flex flex-row">
         <div style= {{width: "30%"}} class="p-2">
              <div style= {{width: "100%"}} class="dropdown">
              <Select id='ProjectDropdown' style={{width: "100%"}} placeholder='Project Name' />


        </div>
              </div>
              <div style= {{width: "15%"}} class="p-2">
              <div style= {{width: "100%"}} class="dropdown">
              <Select id='StatusDropdown' isSearchable={false} style={{width: "100%"}} placeholder='Status' />


        </div>
              </div>
              <div style= {{width: "15%"}} class="p-2">
              <div style= {{width: "100%"}} class="dropdown">
              <Select id='StatusDropdown' style={{width: "100%"}} placeholder='Type' />
        </div>
              </div>
        </div>
            <div style= {{width: "40%",  paddingTop: "13px"}} class="d-flex flex-row-reverse">
            <div style= {{width: "20%"}} class="mr-auto p-2">
              <div style= {{width: "100%"}} class="dropdown">
                <button style= {{width: "100%"}} type="button" class="btn btn-link">
                    Reset All
                </button>
        </div>
              </div>
              <div style= {{width: "25%"}} class="mr-auto p-2">
              <div style= {{width: "100%"}} class="dropdown">
                <button style= {{width: "100%",}} type="button" class="btn btn-dark">
                    Search Filter
                </button>
        </div>
              </div>
            </div>
              
              
        
          </div>
          <div style={{paddingTop: "1%"}} class="d-flex justify-content-between">
         <div style= {{width: "80%"}} class="d-flex flex-row">
         <div style= {{width: "17%"}} class="p-2">
              <div style= {{width: "100%"}} class="dropdown">
              <Select id='AssignmentDateDropdown' style={{width: "100%"}} placeholder='Assignment Date' />
        </div>
              </div>
              <div style= {{width: "16.7%"}} class="p-2">
              <div style= {{width: "100%"}} class="dropdown">
              <Select id='AssignmentDateDropdown' style={{width: "100%"}} placeholder='Received Date' />
        </div>
              </div>
              <div style= {{width: "13%"}} class="p-2">
              <div style= {{width: "100%"}} class="dropdown">
              <Select id='AssignmentDateDropdown' style={{width: "100%"}} placeholder='User Type' />
        </div>
              </div>
              <div style= {{width: "30%"}} class="p-2">
              <div style= {{width: "100%"}} >
              <div style= {{width: "100%"}} class="input-group">
                  <div style= {{width: "100%"}} class="form-outline">
                    <input style= {{width: "70%", backgroundColor: "#F1F3F4", marginTop: '10px'}} id="search-input" type="search" id="form1" class="form-control" placeholder='Search By File Number' />
                  </div>
                </div>
              </div>

              </div>
        </div>
        </div>
      </div>
      <div style={{width: "100%", marginLeft: "0px"}}>
    <div  id='TableDiv' className=''>
    <table className='TableDivItself'  id='example' className='table table-striped' >
        <thead>
            <tr>
              <th>File No.</th>  
              <th>Security Code</th> 
              <th>Project Name</th> 
              <th>Status</th> 
              <th>Assigned Date</th> 
              <th>Price</th> 
      
            </tr>
        </thead>

    </table>
  </div>
  </div>
  <Tabs/>
  </div>
  )
}


export default FileAssignment
