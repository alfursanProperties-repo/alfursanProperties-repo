import React from 'react'
import Select from 'react-select';
import $ from 'jquery'
import 'jquery/dist/jquery.min.js';
//Datatable Modules
import "datatables.net-dt/js/dataTables.dataTables"

function UsersInfo() {
  

        $(document).ready(function(){
           $("#example").DataTable({
               pageLength: 8,
               "bLengthChange": false,
               "ordering": false,
                 "bDestroy": true,
                 "bInfo": false,
                 "dom": "ltipr",
               ajax: {
                   url: "https://property-expert-backend-prod.herokuapp.com/user",
                   dataSrc: ""
               },
               columns: [
                   { data: "name" },
                   { data: "email" },
                   { data: "phoneNo" },
                   { data: "totalRemainingAmount" }, 
                   { data: "dealId" } 
                  
               ],          
              
               iDisplayStart: 0
           });
           })
  return (
    <div>
       <div style={{paddingBottom: "50px"}}>
          <div className='AppHeader'>
        <div class="d-flex justify-content-between">
             <div style= {{paddingTop: "2%"}} class="mr-auto p-2">
             <h6 style= {{paddingTop: "5%"}}>Home - File Assignment</h6>
             </div>
             <div style= {{textAlign: "right"}} className='p-2'>
             <img className='ImageAppHeader' src="logo192.png" alt="Avatar"/>
             </div>
       
         </div>
         </div>
         <div>
   <div id='FileAssignmentUpperDiv' class="d-flex justify-content-between">
   <div class="p-2"><h4>Users</h4></div>
   <div style={{marginRight: "30px", color: "#fff"}} class="p-2"><button style = {{backgroundColor: "#ffc100", color: "#fff", fontSize: "1rem"}} class="btn-sm">Add New User</button></div>
   </div>
   
   </div>
   <div id='UserInfoSearchBarDiv'  class="btn-group">
 <Select id='UserInfoSearchBar'   type="search" class="form-control" placeholder='Search By Name'/>
 <Select id='UserInfoSearchBar'  type="search" class="form-control" placeholder='Search By Email'/>
 <div style= {{width: "60%", marginLeft: '100px'}} class="d-flex flex-row-reverse">
            <div style= {{width: "15%"}} class="mr-auto p-2">
              <div style= {{width: "100%"}} class="dropdown">
                <button style= {{width: "100%"}} type="button" class="btn btn-link">
                    Reset All
                </button>
        </div>
              </div>
              <div style= {{width: "20%"}} class="mr-auto p-2">
              <div style= {{width: "100%"}} class="dropdown">
                <button style= {{width: "100%",}} type="button" class="btn btn-dark">
                    Search Filter
                </button>
        </div>
              </div>
            </div>
 </div>
         <div style= {{backgroundColor: "#fcfcfc", paddingTop: "1%"}} id='TableDiv' className=''>
        <table id='example' className='heavy'>
            <thead>
                <tr>
                  <th>NAME</th>  
                  <th>EMAIL</th> 
                  <th>PHONE</th> 
                  <th>ACCOUNT BALANCE</th> 
                  <th>TYPE</th> 
                </tr>
            </thead>

        </table>
      </div>
      </div>
    </div>
  )
}

export default UsersInfo
