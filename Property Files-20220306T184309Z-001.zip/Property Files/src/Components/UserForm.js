import React, { useEffect, useState } from 'react'
import Select from 'react-select'
import Badge1 from '../Images/Badge1.png'
import SideBar from './SideBar';


const options = [
    { value: 'Admin', label: 'Admin' },
    { value: 'User', label: 'User' },
    { value: 'Employee', label: 'Employee' }
  ];

function UserForm() {
  const [inputValue,setInputValue] = useState('')
  const [selectedValue,setSelectedValue] = useState(null)


  const handleInputChange = value => {
     setInputValue(value)
  }
  const handleChange = value => {
      setSelectedValue(value)
  }
  
  let ValueHoldingObject={}

 if(selectedValue!=null){
    Object.assign(ValueHoldingObject,selectedValue)
 }

 console.log(ValueHoldingObject.value)
 
    return (
      <div>
          <SideBar/>
          <div className='AppHeader' >
         <div class="d-flex justify-content-between">
              <div style= {{paddingTop: "2%"}} class="mr-auto p-2">
              <h6 style= {{paddingTop: "5%"}}>Home - File Assignment</h6>
              </div>
              <div style= {{textAlign: "right"}} className='p-2'>
              <img className='ImageAppHeader' src="logo192.png" alt="Avatar"/>
              </div>
        
          </div>
          </div>
          <div>
    <div id='UpperMostDiv2'  class="d-flex justify-content-between">
    <div class="p-2"><h4>Add New User</h4></div>
   
    </div>
    
    </div>
          
    
        
          <div className='AddNewUserFormDiv' >
          
          <div style={{paddingTop: "1%"}} >
              <img style={{paddingLeft: "1%", paddingRight: "0.5%"}} src={Badge1}/>
              <label style={{fontSize: '20px', fontWeight: "medium" }} >PLATINUM USER</label>
          </div>
        <div id='AddNewFileFormFlexRowDiv' class="d-flex flex-row">
        <div id='AddNewFileFormFlexColumnDiv' class="d-flex flex-column">
        <div class="form-group row">
    <label for="inputPassword" class="col-sm-2 col-form-label"> Type:</label>
    <div style={{width: '460px'}} className='yo'>
       <Select styles={{width: '436px'}} onChange={handleChange} value={selectedValue} options={options} onInputChange={handleInputChange} />
      
     
         </div>
   
  </div>
  <div class="form-group row">
            <label for="inputPassword" class="col-sm-2 col-form-label">Name:</label>
            <div class="col-sm-10">
            <input type="email" class="form-control" id="inputPassword" placeholder="Enter Name"/>
            </div>
        </div>
        <div class="form-group row">
            <label for="inputPassword" class="col-sm-2 col-form-label">Email:</label>
            <div class="col-sm-10">
            <input type="email" class="form-control" id="inputPassword" placeholder="Enter Email"/>
            </div>
        </div>
        <div class="form-group row">
            <label for="inputPassword" class="col-sm-2 col-form-label">Phone:</label>
            <div class="col-sm-10">
            <input type="password" class="form-control" id="inputPassword" placeholder="Password"/>
            </div>
            
        </div>
        
        <div style={{padding: "0"}} class="form-check form-check-inline">
            <label>Badge:</label>
        <div style={{paddingLeft: "87px"}} class="form-check form-check-inline">
  <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio1" value="option1"/>
  <label class="form-check-label" for="inlineRadio1">Platinum User</label>
  </div>
  <div class="form-check form-check-inline">
  <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio2" value="option2"/>
  <label class="form-check-label" for="inlineRadio2">Gold User</label>
</div>

</div>

 

        </div>
        <div id='AddNewFileFormFlexColumnDiv' class="d-flex flex-column">
            <div class="form-group row">
            <label for="inputPassword" class="col-sm-2 col-form-label">Company:</label>
            <div class="col-sm-10">
            <input type="email" class="form-control" id="inputPassword" placeholder="Enter Company"/>
            </div>
        </div>
        <div class="form-group row">
            <label for="inputPassword" class="col-sm-2 col-form-label">CNIC:</label>
            <div class="col-sm-10">
            <input type="email" class="form-control" id="inputPassword" placeholder="Enter CNIC"/>
            </div>
        </div>
        <div class="form-group row">
            <label for="inputPassword" class="col-sm-2 col-form-label">Password:</label>
            <div class="col-sm-10">
            <input type="password" class="form-control" id="inputPassword" placeholder="Password"/>
            </div>
        </div>
        <div style={{height: "100px"}} class="form-group row">
            <label for="inputPassword" class="col-sm-2 col-form-label">Address:</label>
            <div class="col-sm-10">
            <input style={{height: "100px", }} type="email" class="form-control" id="inputPassword1" placeholder="Enter Address"/>
            </div>
        </div>
        <div class="d-flex flex-row-reverse">
        <button  id='AddNewUserFormButton' type="button" class="btn btn-warning">Submit</button>
        </div>
        </div>
        </div>
        </div>
      </div>
      
    )
  }


export default UserForm
