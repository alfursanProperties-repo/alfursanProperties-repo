import React from 'react'
import SocietyImg from '../Images/SocietyImg.png'
function DmsSocietyProfile() {
  return (

    <div>
         <div className='AppHeader'>
         <div class="d-flex justify-content-between">
              <div style= {{paddingTop: "2%"}} class="mr-auto p-2">
              <h6 style= {{paddingTop: "5%"}}>Home - File Assignment</h6>
              </div>
              <div style= {{textAlign: "right"}} className='p-2'>
              <img className='ImageAppHeader'  src="logo192.png" alt="Avatar"/>
              </div>
        
          </div>
      </div>
      <div>
        <div className='FileAssignmentUpperDiv' >
         <div class="d-flex justify-content-between">
              <div style= {{paddingTop: "2%"}} class="mr-auto p-2">
              <h5 style= {{paddingTop: "1%"}}>View Profile</h5>
              </div>
             
        
          </div>
      </div>
      </div>
    <div id='DmsProductFormMainDiv' className ="d-flex flex-row">

        <div id='BorderedDiv' style={{width: "30%", height: "900px", marginTop: "40px"}} class="p-2">
           <div className="d-flex flex-row">
              <div style={{width: "40%", textAlign: "center"}} class="p-2">
                  
                  <div >
                  <img className='Circlular' src={SocietyImg}/>

                  </div>
                 
             </div>
                 
              <div style={{width: "60%"}} class="p-2">

                  <div>
                      <p>SC12252021-0010</p>
                  </div>

                  <div>
                      <h5>State Life Insurance and Co. </h5>
                  </div>



              </div>

          </div>

          <div style={{paddingTop: "30px"}} className="d-flex flex-row">
            <div style={{width: "30%",textAlign: "center"}} class="p-2">
                <label> Email:</label>
            </div>
            <div style={{width: "70%",textAlign: "left"}} class="p-2">
                <p> fgjuvbsfsdfb@gmail.com </p>
            </div>
          </div>
          <div className="d-flex flex-row">
            <div style={{width: "30%",textAlign: "center"}} class="p-2">
                <label> Phone:</label>
            </div>
            <div style={{width: "70%",textAlign: "left"}} class="p-2">
                <p> +012345678 </p>
            </div>
          </div>
          <div className="d-flex flex-row">
            <div style={{width: "30%",textAlign: "center"}} class="p-2">
                <label> Address:</label>
            </div>
            <div style={{width: "70%",textAlign: "left"}} class="p-2">
                <p> Office No. 123 DHA Main Boulevard Campus, Lahore </p>
            </div>
          </div>
          <div className="d-flex flex-row">
            <div style={{width: "30%",textAlign: "center"}} class="p-2">
                <label> Website:</label>
            </div>
            <div style={{width: "70%",textAlign: "left"}} class="p-2">
                <p> www.StateLifeInsurance.com </p>
            </div>
          </div>

          <div style={{marginLeft: "40px", marginTop: "30px"}}>
              <h4>Development Company Info.</h4>
          </div>
          <div style={{paddingTop: "30px"}} className="d-flex flex-row">
            <div style={{width: "30%",textAlign: "center"}} class="p-2">
                <label> Name:</label>
            </div>
            <div style={{width: "70%",textAlign: "left"}} class="p-2">
                <p> State Life Insurence and co. </p>
            </div>
          </div>
          <div className="d-flex flex-row">
            <div style={{width: "30%",textAlign: "center"}} class="p-2">
                <label> Email:</label>
            </div>
            <div style={{width: "70%",textAlign: "left"}} class="p-2">
                <p> www.stateLifeInsurance.com </p>
            </div>
          </div>
           <div className="d-flex flex-row">
            <div style={{width: "30%",textAlign: "center"}} class="p-2">
                <label> Phone No:</label>
            </div>
            <div style={{width: "70%",textAlign: "left"}} class="p-2">
                <p> +0123757474 </p>
            </div>
          </div>
          <div className="d-flex flex-row">
            <div style={{width: "30%",textAlign: "center"}} class="p-2">
                <label> Address:</label>
            </div>
            <div style={{width: "70%",textAlign: "left"}} class="p-2">
                <p> Office No. 123 DHA Main Boulevard Campus, Lahore </p>
            </div>
          </div>
          <div className="d-flex flex-row">
            <div style={{width: "30%",textAlign: "center"}} class="p-2">
                <label> Previous Projects:</label>
            </div>
            <div style={{width: "70%",textAlign: "left"}} class="p-2">
                <p> N/A </p>
            </div>
          </div>
         


          </div>




        <div id='BorderedDiv' style={{width: "70%", marginTop: "40px", marginLeft: "20px", marginRight: "30px", height: "900px"}} class="p-2">
            <div style={{width: "100%", textAlign: "center"}}>
            <button style={{width: "100%", textAlign: "left", backgroundColor: "#efa804"}} type="button" class="btn btn-primary">Owner Information
            </button>
            </div>
            <div style={{paddingTop: "40px"}} className="d-flex flex-row">
            <div style={{width: "30%", paddingLeft: "50px"}} class="p-2">
                <label style={{paddingLeft: "80px"}}> Type:</label>
            </div>
            <div style={{width: "70%",textAlign: "left"}} class="p-2">
                <p> Owner </p>
            </div>
          </div>
           <div className="d-flex flex-row">
            <div style={{width: "30%",}} class="p-2">
                <label style={{paddingLeft: "80px"}}> Phone No:</label>
            </div>
            <div style={{width: "70%",textAlign: "left"}} class="p-2">
                <p> +0123757474 </p>
            </div>
          </div>
          <div className="d-flex flex-row">
            <div style={{width: "30%",}} class="p-2">
                <label style={{paddingLeft: "80px"}}> Previous Projects:</label>
            </div>
            <div style={{width: "70%",textAlign: "left"}} class="p-2">
                <p> N/A </p>
            </div>
          </div>
          <div className="d-flex flex-row">
            <div style={{width: "30%",}} class="p-2">
                <label style={{paddingLeft: "80px"}}> Legal Status:</label>
            </div>
            <div style={{width: "70%",textAlign: "left"}} class="p-2">
                <p> Certified </p>
            </div>
          </div>
          
          <div className="d-flex flex-row">
            <div style={{width: "30%",}} class="p-2">
                <label style={{paddingLeft: "80px"}}> Area:</label>
            </div>
            <div style={{width: "70%",textAlign: "left"}} class="p-2">
                <p> 1000sqft. </p>
            </div>
          </div>
          <div className="d-flex flex-row">
            <div style={{width: "30%",}} class="p-2">
                <label style={{paddingLeft: "80px"}}> Map:</label>
            </div>
            <div style={{width: "70%",textAlign: "left"}} class="p-2">
                <p> N/A </p>
            </div>
          </div>

          <div>

          </div>
        </div>
        
      
    </div>
    </div>
  )
}

export default DmsSocietyProfile
