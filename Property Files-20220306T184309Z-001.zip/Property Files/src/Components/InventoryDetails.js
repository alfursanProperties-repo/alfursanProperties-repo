import React from 'react'
import Select from 'react-select';
import $ from 'jquery'; 
//Bootstrap and jQuery libraries
import 'jquery/dist/jquery.min.js';
//Datatable Modules
import "datatables.net-dt/js/dataTables.dataTables"


function InventoryDetails() {
    $(document).ready(function(){
        $("#example").DataTable({
            pageLength: 9,
            "bLengthChange": false,
            "ordering": false,
              "bDestroy": true,
              "bInfo": false,
              "dom": "ltipr",
            ajax: {
                url: "https://property-expert-backend-prod.herokuapp.com/plot-files",
                dataSrc: ""
            },
            columns: [
                { data: "fileNo" },
                { data: "fileSecurityNo" },
                { data: "fileType" },
                { data: "projectName" }, 
                { data: "status" }, 
                { data: "assignedDate" }, 
                { data: "recievedDate" }, 
                { data: "unitPrice" }
               
            ],          
           
            iDisplayStart: 0
        });
        })
  return (
      <div>
       <div className='AppHeader' >
        <div class="d-flex justify-content-between">
             <div style= {{paddingTop: "2%"}} class="mr-auto p-2">
             <h6 style= {{paddingTop: "5%"}}>Home - File Assignment</h6>
             </div>
             <div style= {{textAlign: "right"}} className='p-2'>
             <img className='ImageAppHeader' src="logo192.png" alt="Avatar"/>
             </div>
       
         </div>
         </div>
         <div>
   <div id='FileAssignmentUpperDiv' class="d-flex justify-content-between">
   <div class="p-2"><h4>Inventory</h4></div>
   <div style={{marginRight: "30px", color: "#fff"}} class="p-2"><button style = {{backgroundColor: "#ffc100", color: "#fff", fontSize: "1rem"}} class="btn-sm">Add New File</button></div>
   </div>
   
   </div>
   <div id='ButtonsAndSearchesDiv'  class="btn-group">
   <Select id='ProjectDropdown'  placeholder='Project Name' />

   <Select id='StatusDropdown'  placeholder='Status' />

   <Select id='StatusDropdown' placeholder='Type' />
<div class="dropdown-menu">
  ...
</div>
<button id='MandatoryFiles' type="button" class="btn btn-link">
                   Show Mandatory Files
               </button>

</div>
<div id='ButtonsAndSearchesDiv'  class="btn-group">
 <input style={{ margin: "10px", backgroundColor: "#ECECEC", color: "#000", maxWidth: "15%"}}  id="search-input" type="search" id="form1" class="form-control" placeholder='Search By File Number'/>
 <input style={{ margin: "10px", backgroundColor: "#ECECEC", color: "#000", maxWidth: "15%"}}  id="search-input" type="search" id="form2" class="form-control" placeholder='Search By File Number'/>
 <Select id='StatusDropdown'  placeholder='User Type' />
 
 <Select id='AssignmentDateDropdown'  placeholder='Assignment Date' />


</div>
    <div style= {{backgroundColor: "#fcfcfc", paddingTop: "1%"}} id='TableDiv' className=''>
    <table   id='example' className='heavy'>
        <thead>
            <tr>
                  <th>File No.</th>  
                  <th>Security Code</th> 
                  <th>File Type</th> 
                  <th>Project Name</th> 
                  <th>Status</th> 
                  <th>Assigned Date</th> 
                  <th>Received Date</th> 
                  <th>Price</th> 
                  <th>Actions</th>
            </tr>
        </thead>

    </table>
  </div>
  </div>

  )
}

export default InventoryDetails
