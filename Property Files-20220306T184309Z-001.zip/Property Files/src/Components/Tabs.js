import { useState } from "react";
import Select from 'react-select';
import './Styles.css';



function Tabs() {
  const [toggleState, setToggleState] = useState(1);

  const toggleTab = (index) => {
    setToggleState(index);
  };

  return (
      <div className="hell212">
   
    <div className="container">
      <div className="bloc-tabs">
      <h4 style={{width: "60%", paddingTop: "10px"}} >File Assignment </h4>
        <button
          className={toggleState === 1 ? "tabs active-tabs" : "tabs"}
          onClick={() => toggleTab(1)}
        >
          Al-fursan Properties
        </button>
        <button
          className={toggleState === 2 ? "tabs active-tabs" : "tabs"}
          onClick={() => toggleTab(2)}
        >
          Others
        </button>
        
     
      </div>

      <div className="content-tabs">
        <div
          className={toggleState === 1 ? "content  active-content" : "content"}
        >
           <div style={{paddingTop: "2%"}} class="d-flex justify-content-between">
          <div style= {{width: "100%"}} class="d-flex flex-row">
         <div style= {{width: "100%"}} class="p-2">
         <div style= {{width: "100%"}} class="btn-group">
         <span style = {{marginRight: "70px", color: "#000"}} class="badge ">Assigned To.</span>
          <Select >
            </Select>
          </div>
          <div style= {{width: "100%", marginTop: "3%"}} class="btn-group">
          <span style = {{marginRight: "60px", color: "#000"}} class="badge ">Assigned Date</span>
          <Select >
            </Select>
          </div>
          </div>
          
          
        </div>
        
        
        
        </div>
        <div style={{paddingLeft: "9px"}}>
        <div style= {{width: "70%", marginTop: "3%"}} class="btn-group">
          <span style = {{marginRight: "105px", color: "#000"}} class="badge ">Status</span>
          <div class="form-check">
              <input style={{backgroundColor: "#EFA804"}} class="form-check-input" type="radio" name="exampleRadios" id="exampleRadios1" value="option1"/>
              <label class="form-check-label" for="exampleRadios1">
                Sold
              </label>
            </div>
            <div style= {{marginLeft: "10px"}} class="form-check">
              <input style={{backgroundColor: "#EFA804"}} class="form-check-input" type="radio" name="exampleRadios" id="exampleRadios2" value="option2"/>
              <label class="form-check-label" for="exampleRadios2">
                Reserved
              </label>
            </div>
            <div style= {{marginLeft: "10px"}} class="form-check">
              <input style={{backgroundColor: "#EFA804"}} class="form-check-input" type="radio" name="exampleRadios" id="exampleRadios3" value="option3"/>
              <label class="form-check-label" for="exampleRadios3">
                Available
              </label>
            </div>
          </div>
        </div>
        <div>
        <div style= {{marginTop: "20px", paddingLeft: "38px"}} class="form-check">
        <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault"/>
        <label class="form-check-label" for="flexCheckDefault">
            Please uncheck it if you want received data and receiving person to be different
        </label>
        </div>
        </div>
        <div style={{marginTop: "10px"}}  class='d-flex flex-row-reverse'>
        <button style={{backgroundColor: "#efa804", color: "#fff"}} type="button" class="btn ">Primary</button>

        </div>

        <div
          className={toggleState === 2 ? "content  active-content" : "content"}
        >
          <h2>Content 2</h2>
          <hr />
          <p>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Sapiente
            voluptatum qui adipisci.
          </p>
        </div>

        <div
          className={toggleState === 3 ? "content  active-content" : "content"}
        >
          <h2>Content 3</h2>
          <hr />
          <p>
            Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eos sed
            nostrum rerum laudantium totam unde adipisci incidunt modi alias!
            Accusamus in quia odit aspernatur provident et ad vel distinctio
            recusandae totam quidem repudiandae omnis veritatis nostrum
            laboriosam architecto optio rem, dignissimos voluptatum beatae
            aperiam voluptatem atque. Beatae rerum dolores sunt.
          </p>
        </div>
      
      </div>
      </div>
    </div>
    </div>
  
  );
}

export default Tabs;