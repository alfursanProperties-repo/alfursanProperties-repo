import React from 'react'
import Select from 'react-select';


function DmsAddNewProductForm() {
  return (
    <div style={{height: "100vh"}}>
        <div>
        <div className='AppHeader'>
         <div class="d-flex justify-content-between">
              <div style= {{paddingTop: "2%"}} class="mr-auto p-2">
              <h6 style= {{paddingTop: "5%"}}>Home - File Assignment</h6>
              </div>
              <div style= {{textAlign: "right"}} className='p-2'>
              <img className='ImageAppHeader'  src="logo192.png" alt="Avatar"/>
              </div>
        
          </div>
      </div>
      </div>
      <div>
        <div className='FileAssignmentUpperDiv' >
         <div class="d-flex justify-content-between">
              <div style= {{paddingTop: "2%"}} class="mr-auto p-2">
              <h5 style= {{paddingTop: "1%"}}>Add New Product</h5>
              </div>
              
        
          </div>
      </div>
      </div>
      <div>
       <div id='DmsProductFormMainDiv' class="d-flex justify-content-between">
       <div  id='DmsProductFormMainRowDiv' class="d-flex flex-row">
       <div style={{width: "50%"}} class="p-2">
       <div id='DivRowsHeight' style={{columnGap: '20px'}} class="d-flex flex-row">
        <div style={{width: "20%"}}  class="p-2">
           
            <label for="inputPassword" class="col-sm-2 col-form-label">ID:</label>
  
        </div>
        <div style={{width: "50%"}}  class="p-2"> <input type="email" class="form-control" id="inputPassword" placeholder="Enter ID"/></div>
        
      </div>
      <div id='DivRowsHeight' style={{columnGap: '20px'}} class="d-flex flex-row">
        <div style={{width: "20%"}}  class="p-2">
           
            <label for="inputPassword" class="col-sm-2 col-form-label">Name:</label>
  
        </div>
        <div style={{width: "50%"}}  class="p-2"> <input type="email" class="form-control" id="inputPassword" placeholder="Enter Name"/></div>
        
      </div>
<div id='DivRowsHeight' style={{columnGap: '20px'}} class="d-flex flex-row">
        <div style={{width: "20%"}}  class="p-2">
           
            <label style={{width: "100%"}} for="inputPassword" class="col-sm-2 col-form-label">Phone No:</label>
  
        </div>
        <div style={{width: "50%"}}  class="p-2"> <input type="email" class="form-control" id="inputPassword" placeholder="Enter Phone Number"/></div>
        
      </div>
<div id='DivRowsHeight' style={{columnGap: '20px'}} class="d-flex flex-row">
        <div style={{width: "20%"}}  class="p-2">
           
            <label style={{width: "100%"}} for="inputPassword" class="col-sm-2 col-form-label">Email:</label>
  
        </div>
        <div style={{width: "50%"}}  class="p-2"> <input type="email" class="form-control" id="inputPassword" placeholder="Enter Email"/></div>
        
      </div>
      <div id='DivRowsHeight' style={{columnGap: '20px'}} class="d-flex flex-row">
        <div style={{width: "20%"}}  class="p-2">
           
            <label style={{width: "100%"}} for="inputPassword" class="col-sm-2 col-form-label">Address:</label>
  
        </div>
        <div  style={{width: "50%", height: "50px"}}  class="p-2"> <input style={{ height: "80px"}} type="email" class="form-control" id="inputPassword" placeholder="Enter Address"/></div>
        
      </div>
      <div DivRowsHeight style={{columnGap: '20px'}} class="d-flex flex-row">
        <div style={{width: "20%" , marginTop: "40px"}}  class="p-2">
           
            <label style={{width: "100%"}} for="inputPassword" class="col-sm-2 col-form-label">Website:</label>
  
        </div>
        <div style={{width: "50%", marginTop: "40px"}}  class="p-2"> <input type="email" class="form-control" id="inputPassword" placeholder="Enter Website"/></div>
        
      </div>
       </div>
       <div style={{width: "50%"}} class="p-2">
       <div id='DivRowsHeight' style={{columnGap: '20px'}} class="d-flex flex-row">
        <div style={{width: "20%"}}  class="p-2">
           
            <label for="inputPassword" class="col-sm-2 col-form-label">Type:</label>
  
        </div>
        <div style={{width: "50%" }}  class="p-2"> <Select type="email" class="form-control" id="inputPassword" placeholder="Select Type"/></div>
        
      </div>
      <div id='DivRowsHeight' style={{columnGap: '20px'}} class="d-flex flex-row">
        <div style={{width: "20%"}}  class="p-2">
           
            <label style={{width: "100%"}} for="inputPassword" class="col-sm-2 col-form-label">Owner Phone No:</label>
  
        </div>
        <div style={{width: "50%"}}  class="p-2"> <input type="email" class="form-control" id="inputPassword" placeholder="Enter Phone Number"/></div>
        
      </div>
<div id='DivRowsHeight' style={{columnGap: '20px'}} class="d-flex flex-row">
        <div style={{width: "20%"}}  class="p-2">
           
            <label style={{width: "100%"}} for="inputPassword" class="col-sm-2 col-form-label">Previous Projects:</label>
  
        </div>
        <div style={{width: "50%"}}  class="p-2"> <input type="email" class="form-control" id="inputPassword" placeholder="Enter Owner Previous Projects"/></div>
        
      </div>
<div id='DivRowsHeight' style={{columnGap: '20px'}} class="d-flex flex-row">
        <div style={{width: "20%"}}  class="p-2">
           
            <label style={{width: "100%"}} for="inputPassword" class="col-sm-2 col-form-label">Legal Status:</label>
  
        </div>
        <div style={{width: "50%"}}  class="p-2"> 
<div style={{marginTop: "8px"}} class="form-check form-check-inline">
  <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio1" value="option1"/>
  <label class="form-check-label" for="inlineRadio1">Certified</label>
</div>
<div class="form-check form-check-inline">
  <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio2" value="option2"/>
  <label class="form-check-label" for="inlineRadio2">Not Certified</label>
</div>
</div>
        
      </div>
      <div id='DivRowsHeight' style={{columnGap: '20px'}} class="d-flex flex-row">
        <div style={{width: "20%"}}  class="p-2">
           
            <label style={{width: "100%"}} for="inputPassword" class="col-sm-2 col-form-label">Area:</label>
  
        </div>
        <div style={{width: "50%"}}  class="p-2"> <input type="email" class="form-control" id="inputPassword" placeholder="Enter Area"/></div>
        
      </div>
      <div id='DivRowsHeight' style={{columnGap: '20px'}} class="d-flex flex-row">
        <div style={{width: "20%" }}  class="p-2">
           
            <label style={{width: "100%"}} for="inputPassword" class="col-sm-2 col-form-label">Map:</label>
  
        </div>
        <div style={{width: "50%", }}  class="p-2"> 
<input type="file"  id="customFile" />
</div>
        
      </div>
           
       </div>

       </div>
       </div>
       </div>
       <div style={{marginTop: "40px"}} >
       <div id='DmsProductFormMainDiv' class="d-flex justify-content-between">
       <div  id='DmsProductFormMainRowDiv' class="d-flex flex-row">
       <div style={{width: "50%"}} class="p-2">
       
      <div id='DivRowsHeight' style={{columnGap: '20px'}} class="d-flex flex-row">
        <div style={{width: "20%"}}  class="p-2">
           
            <label for="inputPassword" class="col-sm-2 col-form-label">Name:</label>
  
        </div>
        <div style={{width: "50%"}}  class="p-2"> <input type="email" class="form-control" id="inputPassword" placeholder="Enter Name"/></div>
        
      </div>
<div id='DivRowsHeight' style={{columnGap: '20px'}} class="d-flex flex-row">
        <div style={{width: "20%"}}  class="p-2">
           
            <label style={{width: "100%"}} for="inputPassword" class="col-sm-2 col-form-label">Phone No:</label>
  
        </div>
        <div style={{width: "50%"}}  class="p-2"> <input type="email" class="form-control" id="inputPassword" placeholder="Enter Phone Number"/></div>
        
      </div>
<div id='DivRowsHeight' style={{columnGap: '20px'}} class="d-flex flex-row">
        <div style={{width: "20%"}}  class="p-2">
           
            <label style={{width: "100%"}} for="inputPassword" class="col-sm-2 col-form-label">Previous Projects:</label>
  
        </div>
        <div style={{width: "50%"}}  class="p-2"> <input type="email" class="form-control" id="inputPassword" placeholder="Enter Previous Projects"/></div>
        
      </div>
   
       </div>
       <div style={{width: "50%"}} class="p-2">
       
      <div id='DivRowsHeight' style={{columnGap: '20px'}} class="d-flex flex-row">
        <div style={{width: "20%"}}  class="p-2">
           
            <label style={{width: "100%"}} for="inputPassword" class="col-sm-2 col-form-label">Email:</label>
  
        </div>
        <div style={{width: "50%"}}  class="p-2"> <input type="email" class="form-control" id="inputPassword" placeholder="Enter Email"/></div>
        
      </div>
      <div id='DivRowsHeight' style={{columnGap: '20px'}} class="d-flex flex-row">
        <div style={{width: "20%"}}  class="p-2">
           
            <label style={{width: "100%"}} for="inputPassword" class="col-sm-2 col-form-label">Address:</label>
  
        </div>
        <div  style={{width: "50%", height: "50px"}}  class="p-2"> <input style={{ height: "80px"}} type="email" class="form-control" id="inputPassword" placeholder="Enter Address"/></div>
        
      </div>
      <div  style={{columnGap: '20px', marginTop: "60px"}} className='d-flex '>
        <div style={{width: "20%"}}  class="p-2">
           
           
  
        </div>
        <div className='d-flex flex-row-reverse' style={{width: "50%"}}  > <button style={{width: "35%", marginRight: "10px", color: "#fff"}} type="button" class="btn btn-warning">Submit</button></div>
        
      </div>
      
           
       </div>

       </div>
       </div>
       </div>
    </div>
  )
}

export default DmsAddNewProductForm
