import React, { useEffect } from 'react'
import {Link} from 'react-router-dom';
import './Styles.css';
import { useState } from 'react';
import Dashboard from '../Images/Dashboard.png'
import Unknown from '../Images/Unknown.png'
import Document from '../Images/Document.png'
import Calculation from '../Images/Calculation.png'
import Thoughts from '../Images/Thoughts.png'
import Analytics from '../Images/Analytics.png'
import Slip from '../Images/Slip.png'
import AlfursanLogo from '../Images/AlfursanLogo.png'
import Plots from '../Images/Plots.png'
import House from '../Images/House.png'
import Apartments from '../Images/Apartments.png'



function SideBar() {
    const [inactive, setInactive] = useState('true')
      

    useEffect(()=> {
        if(inactive){
            document.querySelectorAll('.sub-menu').forEach(el =>{
                el.classList.remove('toggle')
            })
        }
    })
    useEffect(()=> {
        if(inactive){
            document.querySelectorAll('.headings').forEach(el =>{
                el.classList.remove('toggle')
            }) 
        }
    })
    const [expand, setExpand] = useState('false')
  return (
    <div>
        
       <nav class={`sidebar ${inactive ? 'close':'toggle'} `}>
        <header>
            <div class="image-text">
                <span class="image">
                <img src={AlfursanLogo} alt=""/> 
                </span>

               
            </div>

            <i onClick={()=> setInactive(!inactive)} class='bx bx-chevron-right toggle'></i>
        </header>

        <div class="menu-bar">
            <div className='dashboardDiv'>
            <li class="nav-link">
                        <Link to="#">
                         <img src={Dashboard} alt=""/> 
                            <span class="text nav-text">Dashboard</span>
                        </Link>
                    </li> 

            </div>
            <div class="menu">

            <ul  className={`headings ${inactive? "close":"toggle"}`}>
            <li className=''> <h6 > SOCIETY MANAGEMENT</h6></li>
            </ul>
            

                <ul class="menu-links">
                    
               
                    
                    <li class="nav-link">

                   
                    

                        <Link to="/all-societies">
                         <img src={Dashboard} alt=""/> 
                            <span class="text nav-text">All socieities</span>
                        </Link>
                    </li>

                    <li class="nav-link">
                        <Link to="/add-new-society">
                         <img src={Unknown} alt=""/> 
                            <span class="text nav-text">Add new societies</span>
                        </Link>
                    </li>
                    
                    <ul  className={`headings1 ${inactive? "close":"toggle"}`}>
            <li className=''> <h6 > PRODUCT MANAGEMENT</h6></li>
            </ul>

                    <li class="nav-link">
                    
                        <Link to="/inventory">
                         <img src={Plots} alt=""/> 
                            <span class="text nav-text">Plot files</span>
                        </Link>
                    </li>

                    <li class="nav-link">
                        <Link to="">
                         <img  src={House} alt=""/> 
                            <span onClick={() => setExpand(!expand)} class="text nav-text">Houses</span>
                        </Link>
                       
                    </li>

                    <li class="nav-link">
                        <Link to="#">
                         <img src={Apartments} alt=""/>
                            <span class="text nav-text">Apartments </span>
                        </Link>
                    </li>

                    <li class="nav-link">
                        <Link to="#">
                        < img src={Analytics} alt=""/>
                            <span class="text nav-text">View All</span>
                        </Link>
                    </li>
                    <li class="nav-link">
                        <Link to="#">
                         <img src={Slip} alt=""/> 
                            <span class="text nav-text">Add new product</span>
                        </Link>
                    </li>

                 
                    <ul  className={`headings1 ${inactive? "close":"toggle"}`}>
            <li className=''> <h6 > TRANSACTION MANAGEMENT</h6></li>
            </ul>
                
                    <li class="nav-link">
                        <Link to="/transaction-history">
                         <img src={Slip} alt=""/> 
                            <span class="text nav-text">All transactions</span>
                        </Link>
                    </li>
                   
                    <li class="nav-link">
                        <Link to="/payment-history">
                         <img src={Slip} alt=""/> 
                            <span class="text nav-text">All payments</span>
                        </Link>
                    </li>


                    <ul  className={`headings1 ${inactive? "close":"toggle"}`}>
            <li className=''> <h6 > USER MANAGEMENT</h6></li>
            </ul>

            <li class="nav-link">
                        <Link to="/users-list">
                         <img src={Slip} alt=""/> 
                            <span class="text nav-text">Users list </span>
                        </Link>
                    </li>
                    <li class="nav-link">
                        <Link to="/add-new-user-form">
                         <img src={Slip} alt=""/> 
                            <span class="text nav-text">Add new user</span>
                        </Link>
                    </li>
                    <li class="nav-link">
                        <Link to="#">
                         <img src={Slip} alt=""/> 
                            <span class="text nav-text">Rows & Permissions</span>
                        </Link>
                    </li>

                   

                </ul>
            </div>

           
        </div>

    </nav>
    </div>
  )
}

export default SideBar
