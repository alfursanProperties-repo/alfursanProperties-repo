import React from 'react'

function SingleFileDetail() {
  return (
    <div>
      <div>
            <div  className='AppHeader'>
            <div style= {{width: "100%", backgroundColor: "#fcfcfc", height: "60px",paddingRight:"1.5%"}} >
         <div class="d-flex justify-content-between">
              <div style= {{paddingTop: "2%"}} class="mr-auto p-2">
              <h6 style= {{paddingTop: "5%"}}>Home - Inventory - File Detail</h6>
              </div>
              <div style= {{textAlign: "right"}} className='p-2'>
              <img className='ImageAppHeader' src="logo192.png" alt="Avatar"/>
              </div>
        
          </div>
          </div>
            </div>
         <div id='SingleFileUpperDiv' className='d-flex'>
         <div style={{width: "50%"}} class="d-flex flex-row">
        <div  class="p-2"><h4>Muhammad Waqas Cheema - FD12282021-001</h4></div>

        </div>
        <div style={{width: "50%"}} class="d-flex flex-row-reverse">
        <div class="p-2"><button style = {{backgroundColor: "#000", color: "#fff", }} class="btn-sm">Notes</button></div>
        <div class="p-2"><button style = {{backgroundColor: "#ffc100", color: "#fff"}} class="btn-sm">Edit File</button></div>

        </div>
        
      </div>
      <div id='DetailDiv1' className=''>
          <h4>Basic Information</h4>
          <div style= {{margin: "0 -5px", marginTop: "40px"}} className='d-flex'>
              <div className='p-2'>
              <p>Project Name:</p> 
              <p>File Number:</p>
              <p>Security Code:</p>
              <p>Type:</p>
              <p>Status:</p>
              </div>
              <div style= {{margin: "0 50px"}} className='p-2'>
              <p>Qaim Mansions</p>
              <p>File Number</p>
              <p>FD12282021-001</p>
              <p>15 Marla</p>
              <p>Available</p>
              </div>
          </div>
        
      </div>
      <div id='DetailDiv1' style={{marginTop: "30px"}}>
          <h4>Assignment Information</h4>
          <div style= {{margin: "0 -5px", marginTop: "40px"}} className='d-flex'>
              <div className='p-2'>
              <p>Assigned To:</p> 
              <p>Assignment Date:</p>
              <p>Received By:</p>
              <p>Received Date:</p>
              </div>
              <div style= {{margin: "0 50px"}} className='p-2'>
              <p>Shehroz Khan</p>
              <p>14th Feb,2021</p>
              <p>Shehroz Khan</p>
              <p>14th Feb,2021</p>
              </div>
          </div>
        
      </div>
      <div id='DetailDiv1' style={{marginTop: "30px"}}>
          <h4>Pricing Information</h4>
          <div style= {{margin: "0 -5px", marginTop: "40px"}} className='d-flex'>
              <div className='p-2'>
              <p>Assigned To:</p> 
              <p>Assignment Date:</p>
              </div>
              <div style= {{margin: "0 50px"}} className='p-2'>
              <p>Shehroz Khan</p>
              <p>14th Feb,2021</p>
              </div>
          </div>
        
      </div>
      </div>
    </div>
  )
}

export default SingleFileDetail
