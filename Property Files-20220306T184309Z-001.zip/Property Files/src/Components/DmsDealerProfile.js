import React from 'react'
import SocietyImg from '../Images/SocietyImg.png'
import Badge1 from '../Images/Badge1.png'
function DmsDealerProfile() {
  return (
    <div style={{backgroundColor: "#f1f3f4", height: "810px"}}>
      <div className='AppHeader'>
         <div class="d-flex justify-content-between">
              <div style= {{paddingTop: "2%"}} class="mr-auto p-2">
              <h6 style= {{paddingTop: "5%"}}>Home - Poduct - Dealer Profile</h6>
              </div>
              <div style= {{textAlign: "right"}} className='p-2'>
              <img className='ImageAppHeader'  src="logo192.png" alt="Avatar"/>
              </div>
        
          </div>
      </div>
      <div>
      <div className='FileAssignmentUpperDiv' >
         <div class="d-flex justify-content-between">
              <div style= {{paddingTop: "2%"}} class="mr-auto p-2">
              <h5 style= {{paddingTop: "1%"}}>Muhammad Saqib Khan - PLATINUM BADGE</h5>
              </div>
             
        
          </div>
      </div>
      </div>
           
            
        <div id='DmsProductFormMainDiv'  >
        <button style={{width: "100%", textAlign: "left", backgroundColor: "#efa804"}} type="button" class="btn btn-primary">Owner Information
            </button>
          <div class="d-flex flex-row">
        <div style={{width: "50%"}} class="p-2">
        <div style={{columnGap: "20px"}} class="d-flex flex-row">
        <div style={{width: "20%"}} class="p-2">
        
              
                  
                  <div style={{textAlign: "center"}} >
                  <img className='Circlular' src={SocietyImg}/>

                  </div>
                 
             </div>
        
 
        <div style={{width: "40%", marginTop: "20px"}} class="p-2">
          <div>
            <h6> Platinum Badge</h6>
          </div>
          <div>
          <h5>Muhammad Saqib Khan</h5>
        </div>
        </div>
        
       
      </div>
        </div>
        <div style={{width: "50%"}} class="p-2">
        <div class="d-flex flex-row-reverse">
        <div class="p-2">
      
        <div  style={{marginTop: "20px"}} class="p-2">
        <img src={Badge1}/>
        </div>


        </div>
     
      </div>
        </div>
        </div>
        </div>
        <div id='DmsProductFormMainDiv' style={{backgroundColor: "#fff"}}>
        <div style={{paddingTop: "40px"}} className="d-flex flex-row">
            <div style={{width: "20%", paddingLeft: "50px"}} class="p-2">
                <label style={{paddingLeft: "50px"}}> Type:</label>
            </div>
            <div style={{width: "70%",textAlign: "left"}} class="p-2">
                <p> Owner </p>
            </div>
          </div>
           <div className="d-flex flex-row">
            <div style={{width: "20%",}} class="p-2">
                <label style={{paddingLeft: "50px"}}> Phone No:</label>
            </div>
            <div style={{width: "70%",textAlign: "left"}} class="p-2">
                <p> +0123757474 </p>
            </div>
          </div>
          <div className="d-flex flex-row">
            <div style={{width: "20%",}} class="p-2">
                <label style={{paddingLeft: "50px"}}> Previous Projects:</label>
            </div>
            <div style={{width: "70%",textAlign: "left"}} class="p-2">
                <p> N/A </p>
            </div>
          </div>
          <div className="d-flex flex-row">
            <div style={{width: "20%",}} class="p-2">
                <label style={{paddingLeft: "50px"}}> Legal Status:</label>
            </div>
            <div style={{width: "70%",textAlign: "left"}} class="p-2">
                <p> Certified </p>
            </div>
          </div>
          
          <div className="d-flex flex-row">
            <div style={{width: "20%",}} class="p-2">
                <label style={{paddingLeft: "50px"}}> Area:</label>
            </div>
            <div style={{width: "70%",textAlign: "left"}} class="p-2">
                <p> 1000sqft. </p>
            </div>
          </div>
          <div className="d-flex flex-row">
            <div style={{width: "20%",}} class="p-2">
                <label style={{paddingLeft: "50px"}}> Map:</label>
            </div>
            <div style={{width: "70%",textAlign: "left"}} class="p-2">
                <p> N/A </p>
            </div>
          </div>
          </div>
    </div>
  )
}

export default DmsDealerProfile
