import React from 'react'
import SocietyImg from '../Images/SocietyImg.png'
import Badge1 from '../Images/Badge1.png'

function DmsEndUserProfile() {
 
  return (
      <div style={{backgroundColor: "#fff", height: "100vh"}} >
    
    <div className='AppHeader'>
       <div class="d-flex justify-content-between">
            <div style= {{paddingTop: "2%"}} class="mr-auto p-2">
            <h6 style= {{paddingTop: "5%"}}>Home - Poduct - Dealer Profile</h6>
            </div>
            <div style= {{textAlign: "right"}} className='p-2'>
            <img className='ImageAppHeader'  src="logo192.png" alt="Avatar"/>
            </div>
      
        </div>
    </div>
    <div>
    <div style={{backgroundColor: "#f1f3f4"}} className='FileAssignmentUpperDiv' >
       <div class="d-flex justify-content-between">
            <div style= {{paddingTop: "2%"}} class="mr-auto p-2">
            <h5 style= {{paddingTop: "1%"}}>Muhammad Saqib Khan - PLATINUM BADGE</h5>
            </div>
           
      
        </div>
    </div>
    </div>
         
    
      <div id='DmsProductFormMainDiv'  >
      <button style={{width: "100%", textAlign: "left", backgroundColor: "#efa804"}} type="button" class="btn btn-primary">Owner Information
          </button>
        <div class="d-flex flex-row">
      <div style={{width: "50%"}} class="p-2">
      <div style={{columnGap: "20px"}} class="d-flex flex-row">
      <div style={{width: "20%"}} class="p-2">
      
            
                
                <div style={{textAlign: "center"}} >
                <img className='Circlular' src={SocietyImg}/>

                </div>
               
           </div>
      

      <div style={{width: "40%", marginTop: "20px"}} class="p-2">
        <div>
          <h6> Platinum Badge</h6>
        </div>
        <div>
        <h5>Muhammad Saqib Khan</h5>
      </div>
      </div>
      
     
    </div>
      </div>
      
      </div>
      </div>
      
      <div style={{backgroundColor: "#fff", width: "90%", height: "510px"}} id='DmsProductFormMainDiv'>
        <div style={{width: "90%",paddingTop: "50px"}} class="d-flex flex-row">
        <div style={{width: "50%", marginLeft: "30px"}} class="p-2">
         <h5> End-User Information</h5>
         <div style={{paddingTop: "20px"}} className="d-flex flex-row">
            <div style={{width: "30%",}} class="p-2">
                <label > Email:</label>
            </div>
            <div style={{width: "70%",textAlign: "left"}} class="p-2">
                <p> Shehrozkhan76@gmail.com </p>
            </div>
          </div>
          <div className="d-flex flex-row">
            <div style={{width: "30%",}} class="p-2">
                <label> Designation:</label>
            </div>
            <div style={{width: "70%",textAlign: "left"}} class="p-2">
                <p> Assistant Manager </p>
            </div>
          </div>
          <div className="d-flex flex-row">
            <div style={{width: "30%",}} class="p-2">
                <label > S/O D/O W/O :</label>
            </div>
            <div style={{width: "70%",textAlign: "left"}} class="p-2">
                <p>S/O Muhammad Saqib Khan </p>
            </div>
          </div>
          <div className="d-flex flex-row">
            <div style={{width: "30%",}} class="p-2">
                <label >Office No:</label>
            </div>
            <div style={{width: "70%",textAlign: "left"}} class="p-2">
                <p> +0123757474 </p>
            </div>
          </div>
          <div className="d-flex flex-row">
            <div style={{width: "30%",}} class="p-2">
                <label > Mobile No:</label>
            </div>
            <div style={{width: "70%",textAlign: "left"}} class="p-2">
                <p> +0123757474 </p>
            </div>
          </div>
          <div className="d-flex flex-row">
            <div style={{width: "30%",}} class="p-2">
                <label > Address:</label>
            </div>
            <div style={{width: "70%",textAlign: "left"}} class="p-2">
                <p> House No. 245, Street 6, H-13, Islamabad </p>
            </div>
          </div>
        </div>
        <div style={{width: "50%", marginLeft: "30px"}}  class="p-2">
        <h5> Nominee Information</h5>
        <div style={{paddingTop: "20px"}} class="d-flex flex-row">
        
            <div style={{width: "30%",}} class="p-2">
                <label > Name:</label>
            </div>
            <div style={{width: "70%",textAlign: "left"}} class="p-2">
                <p> Muhammad Asad Khan </p>
            </div>
          </div>
          <div className="d-flex flex-row">
            <div style={{width: "30%",}} class="p-2">
                <label >Relationship:</label>
            </div>
            <div style={{width: "70%",textAlign: "left"}} class="p-2">
                <p> Brother </p>
            </div>
          </div>
          <div className="d-flex flex-row">
            <div style={{width: "30%",}} class="p-2">
                <label >Nominee CNIC:</label>
            </div>
            <div style={{width: "70%",textAlign: "left"}} class="p-2">
                <p> House No. 245, Street 6, H-13, Islamabad </p>
            </div>
          </div>
          <div className="d-flex flex-row">
            <div style={{width: "30%",}} class="p-2">
                <label >Nominee Phone:</label>
            </div>
            <div style={{width: "70%",textAlign: "left"}} class="p-2">
                <p> +0123757474 </p>
            </div>
          </div>
            
            
        </div>
        
        </div>
      </div>
      </div>
  )
}

export default DmsEndUserProfile
